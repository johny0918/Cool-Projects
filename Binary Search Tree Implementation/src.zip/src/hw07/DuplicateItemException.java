/* Your Name: Jonathan Santos 
 * Your Course Number (CS2013)
 * Your Section Numbers: 01
 * Description: The purpose of this class is to create a custom exception
 */

package hw07;

public class DuplicateItemException extends Exception{
	public DuplicateItemException(String message) {
		super(message);
	}
}
