
public class PPMImageNotFoundException extends Exception {
	public PPMImageNotFoundException(String message){
		super(message);
	}
}
